Written by Tsendsuren Khurelbaatar.
Email: khtsendsuren@postech.ac.kr



**************************************
D-scan setup installation instruction
**************************************

1. Beam incident angle onto the wedge should be 52 degree.
2. Stationary wedge thickness should adjusted for 4.0 mm thickness.


